﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Programa2
{
    public interface IHasArea
    {
        double Area();
    }
}
