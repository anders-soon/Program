﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Programa2
{
    public class PerimeterOperations
    {
        public double Sum(IEnumerable<IHasPerimeter> shapes)
        {
            double perimeter = 0;
            foreach (var shape in shapes)
                perimeter += shape.Perimeter();
            return perimeter;
        }
    }
}
