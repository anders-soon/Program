﻿using System;
using static System.Net.Mime.MediaTypeNames;

namespace Programa1
{
    class Program
    {
        static void Main(string[] args)
        {
           int opcion2 = 0;

            while (opcion2!= 3)
            {
                Menu();

                string opcion = Console.ReadLine();
                int n = int.Parse(opcion);
                switch (n)
                {
                    case 1:
                        Console.Clear();
                        Console.WriteLine("Usted escogio el patron Prototype:");
                        Console.WriteLine("");
                        Prototipo();
                        Console.Clear();
                        


                        break;
                    case 2:
                        Console.Clear();
                        Console.WriteLine("Usted escogio el patron State");
                        Console.WriteLine("");
                        State();
                        Console.Clear();
                        break;
                    case 3:
                        Console.Clear();
                        Console.WriteLine("Usted escogio el patron Strategy");
                        Console.WriteLine("");
                        Strategy();
                        Console.Clear();
                        break;
                    case 4:
                        Console.Clear();
                        Console.WriteLine("Gracias por utlizar nuestra aplicación");
                        Console.Read();
                        Environment.Exit(0);
                        break;
                    default:
                        Console.Clear();
                        Console.WriteLine("Error no Existe un patron definido");
                        break;
                }
            }

        }







        public static void Prototipo()
        {
            Vehiculo v = new Vehiculo();

            v.Marca = "Peugeot";
            v.Modelo = "306";
            v.Color = "Negro";

            v.TipoCarroceria = new Carroceria();
            v.TipoCarroceria.Material = "Acero";
            v.TipoCarroceria.HabitaculoReforzado = true;
            v.TipoCarroceria.TipoCarroceria = "Monovolumen";

            v.TipoRueda = new Rueda();
            v.TipoRueda.Neumatico = "Bridgestone";
            v.TipoRueda.Llanta = "Aluminio";
            v.TipoRueda.Diametro = 17;

            Vehiculo v2 = v.Clone() as Vehiculo;

            Console.WriteLine(v.VehiculoInfo());
            Console.WriteLine("--------------------------------------");
            v2.Color = "Rojo";
            Console.WriteLine(v2.VehiculoInfo());

            Regresar();
            Console.ReadLine();




        }

        public static void State()
        {
            VehiculoBasico vb = new VehiculoBasico();
            vb.Acelerar();
            vb.Contacto();
            vb.Acelerar();
            vb.Acelerar();
            vb.Acelerar();
            vb.Frenar();
            vb.Frenar();
            vb.Frenar();
            vb.Frenar();

            Regresar();
            Console.ReadLine();

        }


        public static void Strategy()
        {
            Vehiculo2 v = new Vehiculo2();
            v.ConduccionDeportiva();
            v.Acelerar(2.4f);

            Console.WriteLine("");

            v.ConduccionNormal();
            v.Acelerar(2.4f);

            Regresar();
            Console.ReadLine();
        }

        public static void Menu()
        {
            Console.WriteLine("Bienvenido a su Empresa de programación Favorita");
            Console.WriteLine("Por favor seleccione un tipo de Patron:\n");
            Console.WriteLine("1) Patron Prototype");
            Console.WriteLine("2) Patron State");
            Console.WriteLine("3) Patron Strategy");
            Console.WriteLine("4) Salir");
            Console.Write("Seleccione un numero--");
        }

        public static void Regresar()
        {
            Console.WriteLine("Presiones Enter para Regresar al menu");
        }

    }
}