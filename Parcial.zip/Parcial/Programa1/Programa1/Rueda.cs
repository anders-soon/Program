﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Programa1
{
    public class Rueda
    {
        public int Diametro { get; set; }
        public string Llanta { get; set; }
        public string Neumatico { get; set; }
    }
}
