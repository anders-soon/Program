﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Programa1
{
    public class Carroceria
    {
        public bool HabitaculoReforzado { get; set; }
        public string Material { get; set; }
        public string TipoCarroceria { get; set; }
    }
}

